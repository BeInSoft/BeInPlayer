drop table Titre if exists;

create table Titre (
	ID Integer primary key,	
	NOM VARCHAR(255), 	
	GENRE VARCHAR(255),	
	DUREE Integer,
	ARTISTE VARCHAR(255)	
);


INSERT INTO Titre (ID, NOM, GENRE, DUREE, ARTISTE) values (1, 'Papaoutai', 'Electro', 231, 'Stromae');
INSERT INTO Titre (ID, NOM, GENRE, DUREE, ARTISTE) values (2, 'Tous les memes', 'Electro', 211, 'Stromae');
INSERT INTO Titre (ID, NOM, GENRE, DUREE, ARTISTE) values (3, 'Alors on danse', 'Electro', 206, 'Stromae');
INSERT INTO Titre (ID, NOM, GENRE, DUREE, ARTISTE) values (4, 'Formidable', 'Electro', 224, 'Stromae');
INSERT INTO Titre (ID, NOM, GENRE, DUREE, ARTISTE) values (5, 'Ta fete', 'Electro', 276, 'Stromae');